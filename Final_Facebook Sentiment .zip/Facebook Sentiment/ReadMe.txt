Please make sure to install all required libraries listed below before running.
Please make sure to have each set of code in a folder alone and delete all plots before running again if you run into an issue.

pandas~=1.2.0
matplotlib~=3.3.3
textblob~=0.15.3
facebook_scraper